# Task 1: Notes App

Bu görevde, kullanıcıların not ekleyip görüntüleyebileceği basit bir not alma uygulaması geliştirildi.

## Özellikler
- Not ekleme
- Not silme
- Local storage desteği

## Teknolojiler
- React
- CSS

## Nasıl çalıştırılır?
```bash
npm install
npm start
```
