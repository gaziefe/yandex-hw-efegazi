# Task 3: Mini Calculator

Basit matematiksel işlemleri (toplama, çıkarma, çarpma, bölme) yapabilen mini hesap makinesi uygulaması.

## Özellikler
- 4 işlem
- Temizle butonu
- Basit kullanıcı arayüzü

## Teknolojiler
- HTML
- CSS
- JavaScript

## Nasıl çalıştırılır?
`index.html` dosyasını tarayıcıda açmanız yeterlidir.
