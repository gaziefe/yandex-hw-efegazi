# Task 2: Weather App

Bu uygulama, OpenWeatherMap API'si aracılığıyla girilen şehir için güncel hava durumunu göstermektedir.

## Özellikler
- API'den veri çekme
- Şehir arama
- Hata yönetimi

## Teknolojiler
- React
- Axios

## Nasıl çalıştırılır?
```bash
npm install
npm start
```
