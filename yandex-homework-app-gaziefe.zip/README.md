# Yandex Homework App - Gaziefe

Bu depo, Yandex Practicum görevlerini içermektedir. Her görev ayrı klasörlerde düzenlenmiştir.

## Görevler

- [Task 1: Notes App](./task1_notes_app/)
- [Task 2: Weather App](./task2_weather_app/)
- [Task 3: Mini Calculator](./task3_mini_calculator/)

Her görev klasöründe açıklayıcı README ve kod dosyaları yer almaktadır.
